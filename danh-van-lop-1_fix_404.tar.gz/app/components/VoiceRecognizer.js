'use client';
import { useState, useEffect } from 'react';

export default function VoiceRecognizer({ targetWord, onResult }) {
  const [isListening, setIsListening] = useState(false);
  const [status, setStatus] = useState('idle'); // idle, listening, processing

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Trình duyệt không hỗ trợ nhận diện giọng nói. Hãy dùng Chrome.');
      return;
    }
    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = 'vi-VN';
    recognition.continuous = false;
    
    recognition.onstart = () => {
      setIsListening(true);
      setStatus('listening');
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.toLowerCase().trim();
      processResult(transcript);
    };

    recognition.onerror = () => {
      setStatus('error');
      setIsListening(false);
    };

    recognition.onend = () => setIsListening(false);
    recognition.start();
  };

  const processResult = (transcript) => {
    setStatus('processing');
    // Logic so khớp đơn giản (sẽ nâng cấp lên AI so khớp sau)
    const isCorrect = transcript === targetWord.toLowerCase();
    onResult(isCorrect, transcript);
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <button 
        onClick={startListening}
        className={`w-20 h-20 rounded-full flex items-center justify-center text-4xl shadow-lg transition ${isListening ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}
      >
        🎤
      </button>
      <p className="font-hp001 text-xl">{isListening ? 'Đang lắng nghe...' : 'Nhấn vào micro để đọc'}</p>
    </div>
  );
}
