'use client';
import { useState } from 'react';

export default function Game() {
  const [msg, setMsg] = useState('Hãy chọn chữ đúng để câu cá!');
  
  return (
    <div className="p-6 font-hp001 text-center min-h-screen bg-sky-100">
      <h1 className="text-3xl font-bold mb-6">Trò chơi câu cá</h1>
      <p className="mb-8">{msg}</p>
      <div className="grid grid-cols-2 gap-4">
        {['b', 'a', 'ba', 'bo'].map(w => (
          <button 
            key={w} 
            onClick={() => setMsg('Ối, sai rồi! Hãy thử chữ khác nhé.')}
            className="p-8 bg-blue-500 text-white rounded-3xl text-4xl shadow-lg active:scale-95"
          >
            {w}
          </button>
        ))}
      </div>
    </div>
  );
}
