'use client';
import { useState } from 'react';
import VoiceRecognizer from './components/VoiceRecognizer';
import { supabase } from '../lib/supabaseClient';

export default function Page() {
  const [attempts, setAttempts] = useState(0);
  const [feedback, setFeedback] = useState('');

  const saveProgress = async (word, status) => {
    const { error } = await supabase
      .from('user_progress')
      .insert([{ word, status, user_id: 'guest_user' }]);
    if (error) console.error('Lỗi lưu Supabase:', error);
  };

  const handleResult = (isCorrect, transcript) => {
    if (isCorrect) {
      setFeedback('Giỏi quá! Đúng rồi!');
      setAttempts(0);
      saveProgress('ba', 'correct');
    } else {
      setAttempts(prev => prev + 1);
      saveProgress('ba', 'incorrect');
      if (attempts + 1 >= 3) {
        setFeedback('Bạn đã thử 3 lần. Chữ này là "ba". Hãy nghe cô đọc lại nhé: B-A-BA!');
      } else {
        setFeedback('Chưa đúng rồi, bé đọc lại nhé!');
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-yellow-50 p-4 font-hp001">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-gray-800">Bé Vui Học Đọc</h1>
      </header>
      
      <main className="w-full max-w-sm bg-white rounded-3xl shadow-xl p-6 border-4 border-blue-400">
        <div className="text-center mb-8">
          <p className="text-lg text-gray-500 mb-2">Bé hãy đọc chữ này:</p>
          <div className="text-[120px] font-bold tracking-tight leading-none">
            <span className="text-blue-600">b</span>
            <span className="text-red-600">a</span>
          </div>
        </div>

        <VoiceRecognizer targetWord="ba" onResult={handleResult} />
        
        <p className="mt-6 text-center text-red-500 font-bold text-lg h-12">{feedback}</p>
        
        {attempts >= 3 && (
          <button className="w-full mt-4 py-3 bg-green-500 text-white rounded-full text-xl shadow-lg">
            Tiếp tục sang chữ mới
          </button>
        )}
      </main>
    </div>
  );
}
