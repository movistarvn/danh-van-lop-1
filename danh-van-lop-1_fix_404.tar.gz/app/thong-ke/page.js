'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

export default function Statistics() {
  const [stats, setStats] = useState({ correct: 0, incorrect: 0 });

  useEffect(() => {
    async function fetchData() {
      const { data } = await supabase.from('user_progress').select('status');
      if (data) {
        const correct = data.filter(r => r.status === 'correct').length;
        const incorrect = data.filter(r => r.status === 'incorrect').length;
        setStats({ correct, incorrect });
      }
    }
    fetchData();
  }, []);

  return (
    <div className="p-6 font-hp001 text-center min-h-screen bg-yellow-50">
      <h1 className="text-3xl font-bold mb-6">Thống kê của bé</h1>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-green-100 p-6 rounded-2xl">
          <p className="text-4xl text-green-700">{stats.correct}</p>
          <p>Lần đọc đúng</p>
        </div>
        <div className="bg-red-100 p-6 rounded-2xl">
          <p className="text-4xl text-red-700">{stats.incorrect}</p>
          <p>Lần cần cố gắng</p>
        </div>
      </div>
    </div>
  );
}
